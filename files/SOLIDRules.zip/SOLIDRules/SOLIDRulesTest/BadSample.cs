﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestSolidRules
{
	class BadSample
	{
	    public string Method0 () {
			return "Method0";
		}

		public string Method1 () {
			return "Method1";
		}

		public string Method2 () {
			return "Method2";
		}

		public string Method3 () {
			return "Method3";
		}

		public string Method4 () {
			return "Method4";
		}

		public string Method5 () {
			return "Method5";
		}

		public string Method6 () {
			return "Method6";
		}

		public string Method7 () {
			return "Method7";
		}

		public string Method8 () {
			return "Method8";
		}

		public string Method9 () {
			return "Method9";
		}

		public string Method10 () {
			return "Method10";
		}

		public string Method11 () {
			return "Method11";
		}

		public string Method12 () {
			return "Method12";
		}

		public string Method13 () {
			return "Method13";
		}

		public string Method14 () {
			return "Method14";
		}

		public string Method15 () {
			return "Method15";
		}

		public string Method16 () {
			return "Method16";
		}

		public string Method17 () {
			return "Method17";
		}

		public string Method18 () {
			return "Method18";
		}

		public string Method19 () {
			return "Method19";
		}


		public string SameMethod (string a) {
			return "Methodstring";
		}

		public string SameMethod (int a) {
			return "Methodint";
		}

		public string SameMethod (double a) {
			return "Methoddouble";
		}

		public string SameMethod (float a) {
			return "Methodfloat";
		}

		public string SameMethod (decimal a) {
			return "Methoddecimal";
		}


	}
}
