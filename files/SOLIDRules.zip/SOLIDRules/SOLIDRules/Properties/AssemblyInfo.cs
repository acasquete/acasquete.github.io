﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SolidRules")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("IdleBit")]
[assembly: AssemblyProduct("SOLIDRules")]
[assembly: AssemblyCopyright("Copyright © IdleBit 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("73f367cc-df55-42a1-a836-8fb8f1ad4c5e")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
