using System.Collections.Generic;
using System.Linq;
using Microsoft.FxCop.Sdk;

namespace SOLIDRules
{
    /// <summary>
    /// Single Reponsibility Principle Check class
    /// </summary>
    public class SingleResponsibilityCheck : BaseIntrospectionRule
    {
        private const int MaxPublicmethodsPerClass = 10;

        public SingleResponsibilityCheck()
            : base("SingleResponsibility", "SOLIDRules.Rules", typeof(SingleResponsibilityCheck).Assembly) { }

        public override ProblemCollection Check(TypeNode type)
        {
            var methods = new List<string>();
            var cls = type as ClassNode;

            if (cls != null)
            {
                foreach (var methodName in from method in cls.Members
                                           let methodName = method.Name.ToString()
                                           where !methods.Contains(methodName) && (method.IsPublic || method.IsFamily)
                                           select methodName)
                {
                    methods.Add(methodName);
                }

                if (methods.Count > MaxPublicmethodsPerClass)
                {
                    var resolution = GetResolution(new[] { cls.Name.ToString(), methods.Count.ToString() });
                    Problems.Add(new Problem(resolution));
                }
            }

            return Problems;
        }
    }
}
