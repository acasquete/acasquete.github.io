﻿using System.Windows;
using System.Windows.Input;
using BasicMVVM.Services;
using BasicMVVM.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BasicMVVM.Test
{
    [TestClass]
    public class ViewModelTest
    {
        Basic vm = new Basic();

        [AssemblyInitialize]
        public static void RegisterServices(TestContext context)
        {
            ServiceLocator.Instance.Register<IMsgBoxService>(new MockMsgBoxService());
        }

        [TestInitialize]
        public void Initialize()
        {
            vm = new Basic();
        }

        [TestMethod]
        public void CreateInstance()
        {
            Assert.IsInstanceOfType(vm, typeof(Basic));
        }

        // [TestMethod]
        public void BadTestExecuteShowQuestionAndAnswerYes()
        {
            ICommand command = vm.BadShowYesNoQuestionCommand;

            command.Execute(null);

            Assert.AreEqual("Your answer is Yes", vm.Answer);
        }

        [TestMethod]
        public void GoodTestExecuteShowQuestionAndAnswerYes()
        {
            ICommand command = vm.ShowYesNoQuestionCommand;
            var msgBox = vm.GetService<IMsgBoxService>() as MockMsgBoxService;
            msgBox.ShowReturnValue = MessageBoxResult.Yes;
            msgBox.ShowCallCount = 0;

            command.Execute(null);

            Assert.AreEqual("Your answer is Yes", vm.Answer);
            Assert.AreEqual(1, msgBox.ShowCallCount);
        }
    }
}
