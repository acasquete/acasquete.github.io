﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Caching;

namespace SQLCacheDependency
{
    public partial class ServiceBrokerLinQ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<libro> books = (List<libro>)Cache.Get("BooksLinQ");

            if (books == null)
            {
                books = GetBooks();
                Label1.Text = System.DateTime.Now.ToString();
            }

            GridView1.DataSource = books;
            GridView1.DataBind();
        }

        private List<libro> GetBooks()
        {
            DataClasses1DataContext dc = new DataClasses1DataContext();

            var q = from libro in dc.libros select libro;

            List<libro> libros;

            using (SqlConnection connection = new SqlConnection(dc.Connection.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(dc.GetCommand(q).CommandText, connection);
                SqlCacheDependency dependency = new SqlCacheDependency(command);
                command.ExecuteNonQuery();

                libros = q.ToList();
                Cache.Insert("BooksLinQ", libros, dependency);
            }

            return libros;
        }
    }
}