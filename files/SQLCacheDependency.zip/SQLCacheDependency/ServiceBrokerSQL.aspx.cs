﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Caching;
using System.Configuration;

namespace SQLCacheDependency
{
    public partial class ServiceBrokerSQL : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable categories = (DataTable)Cache.Get("Libros");

            if (categories == null)
            {
                categories = GetBooks();
                Label1.Text = System.DateTime.Now.ToString();
            }

            GridView1.DataSource = categories.DefaultView;
            GridView1.DataBind();
        }

        private DataTable GetBooks()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["testConnectionString"].ConnectionString;

            DataTable categories = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT id, titulo FROM dbo.libro", connection);
                SqlCacheDependency dependency = new SqlCacheDependency(command);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = command;

                DataSet dataset = new DataSet();
                adapter.Fill(dataset);
                categories = dataset.Tables[0];
                Cache.Insert("Libros", categories, dependency);
            }

            return categories;
        }

      
    }
}