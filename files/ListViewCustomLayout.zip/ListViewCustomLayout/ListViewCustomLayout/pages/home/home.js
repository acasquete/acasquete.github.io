﻿(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/home/home.html", {

        ready: function (element, options) {


            document.getElementById("cmdAdd").addEventListener("click", function () {
                Data.list.push(Data.getNextItem());
            });

            document.getElementById("cmdRemove").addEventListener("click", function () {
                Data.list.pop();
            });

            document.getElementById("cmdSpiral").addEventListener("click", function () {
                var list = document.querySelector(".listView").winControl;
                list.layout = { type: CustomLayouts.UlamSpiralLayout };
                list.forceLayout();
            });

            document.getElementById("cmdCircle").addEventListener("click", function () {
                var list = document.querySelector(".listView").winControl;
                list.layout = { type: CustomLayouts.CircleLayout };
                list.forceLayout();
            });

        }
    });
})();
