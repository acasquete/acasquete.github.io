﻿(function () {
    "use strict";

    var items = [];
    var max = 81;
    var list = new WinJS.Binding.List(items);

    for (var i = 0; i < max; i++) {
        list.push(getNextItem());
    }

    function getNextItem() {
        var id = list.length + 1;
        return { id: id, background: getGradientColor(id) };
    }

    function getGradientColor (i)
    {
        var frequency = .3;
    
        var r = Math.floor(Math.sin(frequency * i + 0) * 127 + 128);
        var g = Math.floor(Math.sin(frequency * i + 2) * 127 + 128);
        var b = Math.floor(Math.sin(frequency * i + 4) * 127 + 128);

        return 'rgb(' + r + ',' + g + ',' + b + ')';
    }

    WinJS.Namespace.define("Data", {
        list: list,
        getNextItem: getNextItem
    });
})();