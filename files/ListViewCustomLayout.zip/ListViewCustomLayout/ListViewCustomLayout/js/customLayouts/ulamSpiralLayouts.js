﻿WinJS.Namespace.define("CustomLayouts", {
    UlamSpiralLayout: WinJS.Class.define(function (options) {
        this._site = null;
        options = options || {};
    },
    {
        initialize: function (site) {
            this._site = site;
            this._itemSize = { width: 144, height: 72 };
        },

        uninitialize: function () {
            this._site = null;
        },

        layout: function (tree, changedRange, modifiedElements, modifiedGroups) {
            var site = this._site;

            var centerPointY = (site.viewportSize.height - this._itemSize.height) / 2;
            var centerPointX = (site.viewportSize.width - this._itemSize.width) / 2;
               
            var itemsContainer = tree[0].itemsContainer;
            var items = itemsContainer.items;

            for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {

                var point = this._indexToPoint(itemIndex);
                var item = items[itemIndex];

                item.style.left = centerPointX + "px";
                item.style.top = centerPointY + "px";

                item.style.transitionDelay = (itemIndex * 180) + "ms";
                item.style.transform = "translate(" + point.x + 'px, ' + point.y + 'px)';
            }

            return WinJS.Promise.as(); // A Promise or {realizedRangeComplete: Promise, layoutComplete: Promise};
        },

        _indexToPoint: function (n) {
            var c = [[-1, 0, 0, -1, 1, 0], [-1, 1, 1, 1, 0, 0], [1, 0, 1, 1, -1, -1], [1, -1, 0, -1, 0, -1]];

            var square = Math.floor(Math.sqrt(n / 4));

            var y = n - 4 * square * square;
            var x = 2 * square + 1;

            var index = y % x;
            var side = Math.floor(y / x);

            var x1 = c[side][0] * square + c[side][1] * index + c[side][2];
            var y1 = c[side][3] * square + c[side][4] * index + c[side][5];

            return { x: x1 * this._itemSize.width + 8 * x1, y: y1 * this._itemSize.height + 8 * y1 };
        }
    })
});

