﻿using System;
using PostSharp.Aspects;
using System.Windows.Threading;

namespace Threading.PostSharp.WPF
{
    [Serializable]
    public class GUIThreadAttribute : MethodInterceptionAspect
    {
        public override void OnInvoke(MethodInterceptionArgs eventArgs)
        {
            DispatcherObject dispatcherObject = (DispatcherObject)eventArgs.Instance;

            if (dispatcherObject.CheckAccess())
            {
                eventArgs.Proceed();
            }
            else
            {
                dispatcherObject.Dispatcher.Invoke(
                    DispatcherPriority.Normal, 
                    new Action(eventArgs.Proceed));
            }
        }
    }
}
