﻿using System;
using PostSharp.Aspects;
using System.Threading;

namespace Threading.PostSharp.WPF
{
    [Serializable]
    public class WorkerThreadAttribute : MethodInterceptionAspect
    {
        public override void OnInvoke(MethodInterceptionArgs args)
        {
            ThreadPool.QueueUserWorkItem(x => args.Proceed());
        }
    }
}
