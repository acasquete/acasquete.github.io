﻿using System;
using System.Windows;
using System.Threading;
using System.Windows.Threading;

namespace Threading.PostSharp.WPF
{
    public partial class MainWindow : Window
    {
        #region Constructor
        public MainWindow()
        {
            InitializeComponent();
        }
        #endregion

        #region Methods without aspects

        private void buttonStart_Click(object sender, RoutedEventArgs e)
        {
            ThreadPool.QueueUserWorkItem(
               delegate
               {
                   // Do something a hundred times
                   for (int i = 0; i < 100; i++)
                   {
                       Thread.Sleep(20);
                       UpdateProgressBar(i);
                   }
               });
        }

        private void UpdateProgressBar(int value)
        {
            this.Dispatcher.Invoke(
                DispatcherPriority.Normal,
                new Action(() =>
                {
                    this.labelProgress.Content = String.Format("{0}% Completed", value + 1);
                    this.progressBar1.Value = value + 1;
                })     
            );
        }

        #endregion

        #region Methods with aspects

        [WorkerThread]
        private void buttonStartAOP_Click(object sender, RoutedEventArgs e)
        {
            // Do something a hundred times
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(20);
                this.UpdateProgressBarAOP(i);
            }
        }

        [GUIThread]
        private void UpdateProgressBarAOP(int value)
        {
            this.labelProgress.Content = String.Format("{0}% Completed", value + 1);
            this.progressBar1.Value = value + 1;
        }

        #endregion
    }
}
