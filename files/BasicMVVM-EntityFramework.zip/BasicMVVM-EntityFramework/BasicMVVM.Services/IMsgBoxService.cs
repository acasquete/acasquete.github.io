﻿using System.Windows;

namespace BasicMVVM.Services
{
    public interface IMsgBoxService
    {
        MessageBoxResult Show(string messageBoxText, string caption, MessageBoxButton button, MessageBoxImage icon);
    }
}
