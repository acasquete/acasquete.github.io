﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows;
using BasicMVVM.Services;
using BasicMVVM.Models;

namespace BasicMVVM.ViewModels
{
    public sealed class Basic : ViewModelBase
    {
        #region Private members

        private string _title;
        private string _answer;
        private ICommand _SetTitleCommand;
        private ICommand _ResetTitleCommand;
        private ICommand _AddItemCommand;
        private ICommand _RemoveItemCommand;
        private ICommand _ShowYesNoQuestionCommand;
        private BasicModel _selectedItem;

        #endregion

        #region Properties

        public string Title
        {
            get
            {
                return _title;
            }

            set
            {
                _title = value;
                NotifyPropertyChanged("Title");
            }
        }

        public BasicModel SelectedItem
        {
            get
            {
                return _selectedItem;
            }
            set
            {
                _selectedItem = value;
                NotifyPropertyChanged("SelectedItem");
            }
        }

        public string Answer
        {
            get
            {
                return _answer;
            }

            set
            {
                _answer = value;
                NotifyPropertyChanged("Answer");
            }
        }

        public ObservableCollection<BasicModel> Items { get; set; }

        #endregion

        #region Constructor

        public Basic()
        {
            Title = "The title";
            Items = new ObservableCollection<BasicModel>();
        }

        #endregion  

        #region SetTitleCommand

        public ICommand SetTitleCommand
        {
            get
            {
                this._SetTitleCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => Title.Length < 50,
                    ExecuteDelegate = p => Title += " grows! "
                };
                return this._SetTitleCommand;
            }
        }
        
        #endregion

        #region ResetTitleCommand

        public ICommand ResetTitleCommand
        {
            get
            {
                this._ResetTitleCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate = p => Title = "The title"
                };
                return this._ResetTitleCommand;
            }
        }

        #endregion

        #region AddItemCommand

        public ICommand AddItemCommand
        {
            get
            {
                this._AddItemCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate    = p => AddItem()
                };
                return this._AddItemCommand;
            }
        }

        private void AddItem()
        {
            var newItem = new BasicModel();
            newItem.Code = Items.Count == 0 ? 1 : Items[Items.Count - 1].Code + 1;
            newItem.Name = "Item #" + newItem.Code;

            Items.Add(newItem);
            SelectedItem = newItem;
            NotifyPropertyChanged("Items");
        }

        #region RemoveItemCommand

        public ICommand RemoveItemCommand
        {
            get
            {
                this._RemoveItemCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => CanRemove(),
                    ExecuteDelegate    = p => RemoveItem()
                };
                return this._RemoveItemCommand;
            }
        }

        private bool CanRemove()
        {
            return SelectedItem != null;
        }

        private void RemoveItem()
        {
            Items.Remove(SelectedItem);
            NotifyPropertyChanged("Items");
        }

        #endregion

        #endregion

        #region BadShowYesNoQuestionCommand
        
        public ICommand BadShowYesNoQuestionCommand
        {
            get
            {
                this._ShowYesNoQuestionCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate = p => BadShowYesNoQuestion("Are you sure?")
                };
                return this._ShowYesNoQuestionCommand;
            }
        }

        private void BadShowYesNoQuestion(string message)
        {
            MessageBoxResult result;
            result = MessageBox.Show(message, "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    this.Answer = "Your answer is Yes";
                    break;

                default:
                    this.Answer = "Your answer is No";
                    break;
            }
        }

        #endregion

        #region ShowYesNoQuestionCommand

        public ICommand ShowYesNoQuestionCommand
        {
            get
            {
                this._ShowYesNoQuestionCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate = p => GoodShowYesNoQuestion("Are you sure?")
                };
                return this._ShowYesNoQuestionCommand;
            }
        }

        private void GoodShowYesNoQuestion(string message)
        {
            IMsgBoxService msgbox = GetService<IMsgBoxService>();

            MessageBoxResult result = msgbox.Show(message, "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    this.Answer = "Your answer is Yes";
                    break;

                default:
                    this.Answer = "Your answer is No";
                    break;
            }
        }

        #endregion
    }
 }
