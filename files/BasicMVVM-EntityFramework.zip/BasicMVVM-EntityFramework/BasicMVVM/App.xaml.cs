﻿using System.Windows;
using BasicMVVM.Services;

namespace BasicMVVM
{
    public partial class App : Application
    {
        public App()
        {
            ServiceLocator.Instance.Register<IMsgBoxService>(new MsgBoxService());
        }
    }
}
