﻿using System.Windows;
using BasicMVVM.Services;

namespace BasicMVVM.Test
{
    class MockMsgBoxService : IMsgBoxService
    {
        public MessageBoxResult ShowReturnValue;

        public int ShowCallCount;

        public MessageBoxResult Show(string messageBoxText, string caption, MessageBoxButton button, MessageBoxImage icon)
        {
            ShowCallCount++;
            return this.ShowReturnValue;
        }
    }
}
