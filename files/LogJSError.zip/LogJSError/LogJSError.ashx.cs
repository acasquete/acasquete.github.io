﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Management;

namespace LogJSError
{
    public class LogJSError : IHttpHandler
    {
        public bool IsReusable { get { return false; } }

public void ProcessRequest(HttpContext context)
{
    HttpRequest request = context.Request;

    string msg = request["msg"];
    string url = request["url"];
    string line = request["line"];
    string agent = request.ServerVariables["HTTP_USER_AGENT"];

    if (!string.IsNullOrEmpty(msg))
    {
        WebBaseEvent.Raise(new WebJSErrorEvent(this, msg, line, url, agent));
    }
}

    }
}