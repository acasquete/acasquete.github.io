﻿function LogJSError (sMsg, sUrl, sLine)
{
    var handler_url = "LogJSError.ashx";

    var params = "msg=" + encodeURIComponent(sMsg);
    params += "&url=" + encodeURIComponent(sUrl);
    params += "&line=" + encodeURIComponent(sLine);

    var http = XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

    http.open("POST", handler_url, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.setRequestHeader("Content-length", params.length);
    http.setRequestHeader("Connection", "close");
    http.send(params);

    return true;
}

window.onerror = LogJSError;