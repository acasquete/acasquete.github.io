﻿using System.Web.Management;

namespace LogJSError
{
    public class WebJSErrorEvent : WebBaseErrorEvent
    {
       public string msg { get; set; }
       public string line { get; set; }
       public string url { get; set; }
       public string agent { get; set; }

       public WebJSErrorEvent(object source, string msg, string line, string url, string agent)
           : base (msg, source, WebEventCodes.WebExtendedBase, new System.Exception(msg))
       {
           this.msg = msg;
           this.line = line;
           this.url = url;
           this.agent = agent;
       }

       public override void FormatCustomEventDetails(WebEventFormatter formatter)
       {
           base.FormatCustomEventDetails(formatter);

           formatter.AppendLine("Error message: " + this.msg);
           formatter.AppendLine("Line: " + this.line);
           formatter.AppendLine("Url: " + this.url);
           formatter.AppendLine("Agent: " + this.agent);
       }
    }
}