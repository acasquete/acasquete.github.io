﻿using System;

namespace BcnDevCon.HelloAOP
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloAOP();

            Console.ReadKey();
        }
        
        [Log]
        public static void HelloAOP()
        {
            Console.WriteLine("Hello AOP!");
        }
    }
}
