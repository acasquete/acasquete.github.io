﻿using System;
using System.Reflection;
using PostSharp.Aspects;

namespace BcnDevCon.HelloAOPGood
{
    [Serializable]
    public class LogAttribute : OnMethodBoundaryAspect
    {
        private string _methodName;

        public override void CompileTimeInitialize(MethodBase method, AspectInfo aspectInfo)
        {
            _methodName = method.DeclaringType.FullName + "." + method.Name;
        }

        public override void OnEntry(MethodExecutionArgs args)
        {
           Console.WriteLine("{0}: Enter", _methodName);
        }

        public override void OnSuccess(MethodExecutionArgs args)
        {
            Console.WriteLine("{0}: Success", _methodName);
        }

        public override void OnException(MethodExecutionArgs args)
        {
            Console.WriteLine("{0}: Exception {1}", _methodName);
        }
    }
}
