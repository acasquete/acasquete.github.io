﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BcnDevCon.HelloAOPGood
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloWorld();

            Console.ReadKey();
        }

        [Log]
        public static void HelloWorld()
        {
            Console.WriteLine("Hello AOP!");
        }
    }
}
