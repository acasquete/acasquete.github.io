﻿using System;
using System.Linq;
using System.Reflection;
using Castle.DynamicProxy;

namespace BcnDevCon.DynamicProxy
{
    [Serializable]
    public class LoggerInterceptorSelector : IInterceptorSelector
    {
        #region IInterceptorSelector Members

        public IInterceptor[] SelectInterceptors(
            Type type, MethodInfo method, IInterceptor[] interceptors)
        {
            if (type.GetCustomAttributes(typeof(LogAttribute), true).Any()
                || method.GetCustomAttributes(typeof(LogAttribute), true).Any())
            {
                return new[] { new LoggerInterceptor() };
            }
            return null;
        }

        #endregion
    }
}