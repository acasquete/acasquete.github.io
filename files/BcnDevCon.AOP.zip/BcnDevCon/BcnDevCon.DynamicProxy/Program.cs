﻿using System;
using Castle.DynamicProxy;

namespace BcnDevCon.DynamicProxy
{
    class Program
    {
        static void Main(string[] args)
        {
            var customer = CreateProxy<Customer>(1, "Alex", 100.00m);
            customer.AddCredit(100);
            customer.GetCredit(200);
            customer.CanGetCredit(100);

            Console.WriteLine("Credit: {0}", customer.Credit);

            SaveAssembly();

            Console.ReadKey();
        }

        private static T CreateProxy<T>(params object[] arguments)
        {
            var proxyGenerator = new ProxyGenerator();
            var options = new ProxyGenerationOptions();
            options.Selector = new LoggerInterceptorSelector();
            return (T)proxyGenerator.CreateClassProxy(typeof(T), options, arguments);
        }

        public static void SaveAssembly()
        {
            const string weakAssemblyName = "BcnDevCon.DynamicProxy.Proxies";
            const string weakModulePath = "BcnDevCon.DynamicProxy.Proxies.dll";

            var moduleScope = new ModuleScope(true, true, ModuleScope.DEFAULT_ASSEMBLY_NAME, ModuleScope.DEFAULT_FILE_NAME, weakAssemblyName, weakModulePath);
            var defaultProxyBuilder = new DefaultProxyBuilder(moduleScope);
            var proxyGenerator = new ProxyGenerator(defaultProxyBuilder);
            var options = new ProxyGenerationOptions { Selector = new LoggerInterceptorSelector() };
            var customer = (Customer)proxyGenerator.CreateClassProxy(typeof(Customer), options, new object[] { 1, "Alex", 100.0m });

            moduleScope.SaveAssembly(false);

        }
    }
}
