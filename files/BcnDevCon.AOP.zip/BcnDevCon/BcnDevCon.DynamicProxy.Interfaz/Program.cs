﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.DynamicProxy;

namespace BcnDevCon.DynamicProxy
{
    class Program
    {
        static void Main(string[] args)
        {
            var customer = CrearProxy<ICustomer>(new Customer(1, "Alex", 1000));
            customer.AddCredit(500);
            customer.GetCredit(1500);
            customer.CanGetCredit(100);

            Console.WriteLine("Credit: {0}", customer.Credit);

            SaveAssembly();
            Console.ReadKey();
        }

        private static TInterface CrearProxy<TInterface>(TInterface target)
            where TInterface : class
        {
            var proxyGenerator = new ProxyGenerator();
            var options = new ProxyGenerationOptions { Selector = new LoggerInterceptorSelector() };

            return proxyGenerator
                .CreateInterfaceProxyWithTargetInterface(target, options);
        }

        public static void SaveAssembly()
        {
            const string weakAssemblyName = "BcnDevCon.DynamicProxyI.Proxies";
            const string weakModulePath = "BcnDevCon.DynamicProxyI.Proxies.dll";

            var moduleScope = new ModuleScope(true, true, ModuleScope.DEFAULT_ASSEMBLY_NAME, ModuleScope.DEFAULT_FILE_NAME, weakAssemblyName, weakModulePath);
            var defaultProxyBuilder = new DefaultProxyBuilder(moduleScope);
            var proxyGenerator = new ProxyGenerator(defaultProxyBuilder);
            var options = new ProxyGenerationOptions { Selector = new LoggerInterceptorSelector() };
            var customer = proxyGenerator
                .CreateInterfaceProxyWithTargetInterface<ICustomer>(new Customer(1, "Alex", 1000), options);

            moduleScope.SaveAssembly(false);

        }
    }
}
