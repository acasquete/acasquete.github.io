using System;

namespace BcnDevCon.DynamicProxy
{
    [Log]
    public class Customer : ICustomer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Credit { get; set; }

        public Customer(int id, string name, decimal initialCredit)
        {
            Id = id;
            Name = name;
            Credit = initialCredit;
        }

        public virtual void AddCredit(decimal amount)
        {
            Credit += amount;
        }

        public virtual void GetCredit(decimal amount)
        {
            if (!CanGetCredit(amount))
            {
                throw new InvalidOperationException("No credit.");
            }
            Credit -= amount;
        }

        public virtual bool CanGetCredit(decimal amount)
        {
            return Credit >= amount;
        }
    }
}