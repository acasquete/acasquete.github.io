﻿using System;
using Castle.DynamicProxy;

namespace BcnDevCon.DynamicProxy
{
    [Serializable]
    public class LoggerInterceptor : IInterceptor
    {
        #region IInterceptor Members

        public void Intercept(IInvocation invocation)
        {
            Console.WriteLine("Enter to {0}", invocation.Method.Name);
            invocation.Proceed();
            Console.WriteLine("Exit from {0}", invocation.Method.Name);
        }

        #endregion
    }
}