﻿using System;

namespace BcnDevCon.DynamicProxy
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
	public class LogAttribute : Attribute
	{}
}