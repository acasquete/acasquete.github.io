﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleTicTacToe
{
    class MiniMax
    {
        public int stats = 0;

        public Movement MiniMaxBasic(Board board, int player)
        {
            if (board.GetWinner() != 0 || board.IsTie())
            {
                Movement mov = new Movement();
                mov.Value = board.GetWinner();
                
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(true);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.SetMove(successor, player);
                    Movement tmp = MiniMaxBasic(successorBoard, -player);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }
                }
                return best;
            }
        }

        public Movement MiniMaxAlphaBeta(Board board, int player, int alpha, int beta)
        {
            int win = board.GetWinner();

            if (win != 0 || board.IsTie())
            {
                Movement mov = new Movement();
                mov.Value = win;
                stats++;
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(false);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.SetMove(successor, player);
                    Movement tmp = MiniMaxAlphaBeta(successorBoard, -player, alpha, beta);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }

                    if (player == -1 && best.Value < beta)
                        beta = best.Value;
                    else if (player == 1 && best.Value > alpha)
                        alpha = best.Value;

                    if (alpha > beta)
                    {
                        return best;
                    }
                }
                return best;
            }
        }

        public Movement MiniMaxAlphaBetaDepth(Board board, int player, int depth, int alpha, int beta)
        {
            int winner = board.GetWinner();
            if ( winner != 0 || board.IsTie() || depth == 6)
            {
                Movement mov = new Movement();
                mov.Value = winner;
                stats++;
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(false);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.SetMove(successor, player);
                    Movement tmp = MiniMaxAlphaBetaDepth(successorBoard, -player, depth+1, alpha, beta);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }

                    if (player == -1 && best.Value < beta)
                        beta = best.Value;
                    else if (player == 1 && best.Value > alpha)
                        alpha = best.Value;

                    if (alpha > beta)
                    {
                        return best;
                    }
                }
                return best;
            }
        }

    }
}
