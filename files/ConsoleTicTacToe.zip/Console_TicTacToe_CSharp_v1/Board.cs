﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ConsoleTicTacToe 
{
    class Board : ICloneable
    {
        int[] board = new int[9];

        
        public Board()
        {

        }

        public Board(int[] values)
        {
            int i = 0;
            while (i < 9)
            {
                board[i] = values[i];
                i++;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("┌───┬───┬───┐");

            for (int i = 0; i < board.Length; i += 3)
            {
                sb.AppendLine(String.Format("│ {0} │ {1} │ {2} │", Casilla(i), Casilla(i+1), Casilla(i+2)));
                if (i < 6) sb.AppendLine("├───┼───┼───┤");
            }

            sb.AppendLine("└───┴───┴───┘");

            return sb.ToString();
        }

        public string Casilla(int value)
        {
            string s = value.ToString();
            if (board[value] == 1) s = "X";
            else if (board[value] == -1) s="O";

            return s;
        }

        public bool IsValidMove(int position)
        {
            return board[position] == 0;
        }

        public int[] GetAllowedMovements(bool randomStart)
        {
            List<int> movements = new List<int>();

            int j = 0;

            if (randomStart)
            {
                j = new Random().Next(0, 8);
            }

            for (int i = 0; i < 9; i++, j++)
            {
                if (j > 8) j = 0;
                if (board[j] == 0) movements.Add(j);
            }
            return (movements.ToArray());
        }

        public void SetMove(int position, int value)
        {
            board[position] = value;
        }

        public int GetWinner()
        {
            int winner = 0;
            int[,] winning = new int[8, 3] { {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, 
                                             {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, 
                                             {0, 4, 8}, {2, 4, 6} };

            for (int i = 0; i < 8 && winner == 0; i++)
            {
                if (board[winning[i, 0]] == board[winning[i, 1]] &&
                    board[winning[i, 1]] == board[winning[i, 2]] &&
                    board[winning[i, 0]] != 0)
                {
                    winner = board[winning[i, 0]];
                }
            }

            return winner;
        }

        public bool IsTie()
        {
            return Array.IndexOf(board, 0) == -1;
        }

        public object Clone()
        {
            Board temp = new Board(board);
            return temp;
        } 
    }


}
