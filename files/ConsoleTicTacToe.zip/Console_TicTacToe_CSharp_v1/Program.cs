﻿using System;
using System.Collections.Generic;

namespace ConsoleTicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            TicTacToe ttt = new TicTacToe();
            ttt.DrawBoard();

            while (!ttt.GameEnded())
            {
                ttt.NextTurn();
                ttt.DrawBoard();
                ttt.CheckWinner();
            }

            Console.ReadLine();
        }
    }
}
