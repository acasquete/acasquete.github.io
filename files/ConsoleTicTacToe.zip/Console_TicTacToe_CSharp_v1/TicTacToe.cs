﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Diagnostics;

namespace ConsoleTicTacToe
{
    class TicTacToe 
    {
        Board board;
        int turn = 0;

        public TicTacToe()
        {
            board = new Board();
        }

        public void DrawBoard()
        {
            Console.Clear();
            Console.WriteLine("tic-tac-toe game console v1.0 written by alex casquete");
            Console.WriteLine();
            Console.WriteLine(board);
        }

        public void NextTurn()
        {
            if (turn % 2 == 0)
            {
                PlayerMove();
            }
            else
            {
                ComputerMove();
            }
            turn++;
        }

        public void PlayerMove()
        {
            int move = 0;

            Console.Write("enter your move (0 to 8): ");
            Int32.TryParse(Console.ReadLine(), out move);

            if (move > 8 || move < 0)
            {
                Console.WriteLine("invalid move!");
                this.PlayerMove();
            }
            else 
            {
                if (!board.IsValidMove(move))
                {
                    Console.WriteLine("this position is already occupied!");
                    this.PlayerMove();
                }
                else
                {
                    board.SetMove(move, 1);
                }
            }
            
        }

        public void ComputerMove()
        {
            MiniMax minmax = new MiniMax();
            
            Stopwatch watch = new Stopwatch();
            watch.Start();
            board.SetMove(minmax.MiniMaxAlphaBetaDepth(board, -1, 0, -1, 1).Position, -1);
            watch.Stop();
            Console.WriteLine("time execution: " + watch.ElapsedMilliseconds + "ms computed moves: " + minmax.stats);
            Console.WriteLine("\npress a key to continue");
            Console.ReadKey();
        }

        public void CheckWinner ()
        {
            if (board.IsTie())
            {
                Console.WriteLine("game is tie!");
            }
            else
            {
                int winner = board.GetWinner();

                if (winner == -1)
                {
                    Console.WriteLine("I win!");
                }
                else if (winner == 1)
                {
                    Console.WriteLine("You win!");
                }
            }
        }

        public Boolean GameEnded()
        {
            return (board.GetWinner() != 0 || board.IsTie());
        }

    }
}
