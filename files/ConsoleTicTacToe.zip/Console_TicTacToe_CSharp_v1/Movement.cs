﻿using System;

namespace ConsoleTicTacToe
{
    class Movement
    {
        private int value;
        private int position;

        /// <summary>
        /// Constructor
        /// </summary>
        public Movement() { }

        #region Public Properties

        public int Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

        public int Position
        {
            get { return position; }
            set { position = value; }
        }

        #endregion
    }
}
