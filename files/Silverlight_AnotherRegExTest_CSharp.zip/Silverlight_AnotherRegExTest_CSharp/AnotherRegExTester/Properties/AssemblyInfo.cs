﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AnotherRegExTester")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("IdleBit")]
[assembly: AssemblyProduct("AnotherRegExTester")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("98e25397-9124-452f-b030-15a2747ca724")]
[assembly: AssemblyVersion("1.0.1.0")]
[assembly: AssemblyFileVersion("1.0.1.0")]
