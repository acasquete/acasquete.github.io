﻿namespace AnotherRegExTester
{
    public class RegExpression
    {
        public string Group { get; set; }
        public string Pattern { get; set; }
        public string Description { get; set; }
    }
}
