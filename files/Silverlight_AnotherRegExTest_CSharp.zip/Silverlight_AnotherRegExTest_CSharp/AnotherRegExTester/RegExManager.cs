﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Windows.Browser;
using System.Xml.Linq;

namespace AnotherRegExTester
{
    public class RegExManager
    {
        IEnumerable<RegExpression> _expressions;
        public event EventHandler LoadedXml;
        public string MatchCount { get; set; }
        public string ReplaceResult { get; set; }

        public RegExManager () {}

        /// <summary>
        /// 
        /// </summary>
        public void LoadXml ()
        {
            
            WebClient xmlClient = new WebClient();
            xmlClient.OpenReadCompleted += new OpenReadCompletedEventHandler(XmlClientOpenReadCompleted);
            xmlClient.OpenReadAsync(new Uri("http://www.idlebit.es/silverlight/regex.xml", UriKind.RelativeOrAbsolute));
            //xmlClient.OpenReadAsync(new Uri("http://localhost:1044/regex.xml", UriKind.RelativeOrAbsolute));
        }

        private void XmlClientOpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                HtmlPage.Window.Alert(e.Error.ToString());
            }
            else
            {
                var s = e.Result;
                XElement xml = XElement.Load(s);

                // Load all regular expressions
                _expressions = from x in xml.Elements("Expression")
                               orderby x.Element("Description").Value
                               select new RegExpression
                               {
                                   Pattern = x.Element("Pattern").Value,
                                   Description = x.Element("Description").Value,
                                   Group = x.Attribute("Group").Value
                               };
            }

            EventHandler handler = LoadedXml;
            if (handler != null) handler(this, EventArgs.Empty);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IOrderedEnumerable<KeyValuePair<string, string>> GetSourceTypes ()
        {
            Dictionary<string, string> sourceTypes = (from x in _expressions
                                                  select new { x.Group })
                                                     .Distinct()
                                                     .ToDictionary((w) => w.Group.ToString(), (w) => w.Group.ToString(), StringComparer.CurrentCulture);

            sourceTypes.Add("", "All");

            return sourceTypes.OrderBy(x => x.Key);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="typeValue"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetSourceRegEx(string typeValue)
        {
            var regexs = from x in _expressions
                            orderby x.Description
                            select new
                            {
                                pattern = x.Pattern,
                                description = x.Description,
                                groupdesc = x.Group
                            };

            if (typeValue != String.Empty)
            {
                regexs = regexs.Where(x => x.groupdesc == typeValue);
            }

            var source = regexs.ToDictionary((w) => w.pattern.ToString(), (w) => w.description.ToString(), StringComparer.CurrentCulture);

            return source;
        }


        private string CheckWholeString(string regexpression, bool ischecked)
        {
            if (ischecked)
            {
                if (regexpression.Substring(0, 1) != "^") regexpression = "^" + regexpression;
                if (regexpression.Substring(regexpression.Length - 1, 1) != "$") regexpression = regexpression + "$";

                return regexpression;
            }
            if (regexpression.Substring(0, 1) == "^") regexpression = regexpression.Substring(1);
            if (regexpression.Substring(regexpression.Length - 1, 1) == "$")
                regexpression = regexpression.Substring(0, regexpression.Length - 1);

            return regexpression;
        }

        public void Getresult(string regexpression, bool casesensitive, string cadena, string replace, bool whole)
        {
            if (regexpression == null) throw new ArgumentNullException("regexpression");

            try
            {
                regexpression = this.CheckWholeString(regexpression, whole);
                Regex ex = new Regex(regexpression, !casesensitive ? RegexOptions.IgnoreCase : RegexOptions.None);
                ReplaceResult = ex.Replace(cadena, replace);
                MatchCollection mc = ex.Matches(cadena);
                MatchCount = String.Format("Replacement result ({0} matches):", mc.Count);
            }
            catch (ArgumentException ex)
            {
                ReplaceResult = String.Format("#ERROR# {0}", ex.Message);
                MatchCount = String.Empty;
            }
        }
    }

    
}
