﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Windows.Browser;
using System.Xml.Linq;

namespace AnotherRegExTester
{
    public partial class MainPage : UserControl
    {
        private readonly RegExManager _mngr = new RegExManager();

        public MainPage()
        {
            InitializeComponent();
            _mngr.LoadedXml += new EventHandler(MngrLoaded);
            _mngr.LoadXml();
        }

        private void MngrLoaded(object sender, EventArgs e)
        {
            cmbRegExType.ItemsSource = _mngr.GetSourceTypes();
            cmbRegExType.DisplayMemberPath = "Value";
            cmbRegExType.SelectedValuePath = "Key";
            cmbRegExType.SelectedValue = "Web";
        }

        private void CmbRegExTypeSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedType = cmbRegExType.SelectedValue.ToString();
            cmbRegEx.ItemsSource = _mngr.GetSourceRegEx(selectedType);
            cmbRegEx.DisplayMemberPath = "Value";
            cmbRegEx.SelectedValuePath = "Key";
            cmbRegEx.SelectedIndex = 0;
        }

        private void Update()
        {
            _mngr.Getresult(tbRegEx.Text, cbCaseSensitive.IsChecked.GetValueOrDefault(), tbString.Text, tbReplace.Text, cbWholeString.IsChecked.GetValueOrDefault());

            tbResult.Text = _mngr.ReplaceResult;
            lbResult.Text = _mngr.MatchCount;
        }

        private void AllTextBoxTextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void UserControlLoaded(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void CbCaseSensitiveClick(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void AllTextBoxGotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.SelectAll();
        }

        private void CbWholeStringClick(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void CmbRegExSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbRegEx.SelectedIndex > -1)
            {
                tbRegEx.Text = cmbRegEx.SelectedValue.ToString();
            }
        }


        

       
    }
}
