﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using System.Data;
using System.Collections;

namespace BindingEntityDataReader
{
    class ProductData
    {
        public IEnumerable GetProducts ()
        {
            return this.Query("SELECT VALUE p FROM AdventureWorksLT2008Entities.Products as p", new
            {
                Name = (string)"",
                ProductNumber = (string)"",
                ListPrice = (decimal)1,
                Size = (string)"",
                SellEndDate = DateTime.Now
            });
        }

        public IEnumerable<T> Query<T>(string queryString, T cls) where T : class
        {
            var results = new List<T>();

            using (var connection = new EntityConnection("name=AdventureWorksLT2008Entities"))
            {
                connection.Open();

                using (var command = new EntityCommand(queryString, connection))
                {
                    var reader = command.ExecuteReader(CommandBehavior.SequentialAccess);

                    var properties = from j in cls.GetType().GetProperties().ToList()
                                     select j.Name;

                    while (reader.Read())
                    {
                        var values = new List<object>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            if (properties.Contains(reader.GetName(i)))
                            {
                                object value = reader[i];
                                Type convert = reader.GetFieldType(i);
                                values.Add(value is System.DBNull ? null : Convert.ChangeType(value, convert));
                            }
                        }

                        T record = Activator.CreateInstance(cls.GetType(), values.ToArray()) as T;

                        results.Add(record);
                    }
                    connection.Close();    
                }

                return results.AsEnumerable();
            }
        }
    }
}
