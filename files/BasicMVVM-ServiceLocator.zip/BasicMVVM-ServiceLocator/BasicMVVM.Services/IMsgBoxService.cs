﻿using System.Windows;
using System.Windows.Input;

namespace BasicMvvm.Services
{
    public interface IMsgBoxService
    {
        MessageBoxResult Show(string messageBoxText, string caption, MessageBoxButton button, MessageBoxImage icon);
    }
}
