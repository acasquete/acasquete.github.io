﻿using System;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Input;
using BasicMVVM.Models;
using System.Windows;
using BasicMvvm.Services;

namespace BasicMVVM.ViewModels
{
    public class ViewModel : ViewModelBase
    {
        #region Private members

        private string _title;
        private string _answer;
        private ICommand _SetTitleCommand;
        private ICommand _ResetTitleCommand;
        private ICommand _AddItemCommand;
        private ICommand _RemoveItemCommand;
        private ICommand _ShowYesNoQuestionCommand;
        private Model _selectedItem;

        #endregion

        #region Constructor

        public ViewModel()
        {
            Title = "The title";
            Items = new ObservableCollection<Model>();
        }

        #endregion  

        #region SetTitleCommand

        public ICommand SetTitleCommand
        {
            get
            {
                this._SetTitleCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => CanUpdateTitle(),
                    ExecuteDelegate    = p => SetTitle()
                };
                return this._SetTitleCommand;
            }
        }

        private bool CanUpdateTitle()
        {
            return Title.Length < 50;
        }

        private void SetTitle()
        {
            Title += " grows! ";
        }
        
        #endregion

        #region ResetTitleCommand

        public ICommand ResetTitleCommand
        {
            get
            {
                this._ResetTitleCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate    = p => ResetTitle()
                };
                return this._ResetTitleCommand;
            }
        }

        private void ResetTitle()
        {
            Title = "The title";
        }

        #endregion

        #region AddItemCommand

        public ICommand AddItemCommand
        {
            get
            {
                this._AddItemCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate    = p => AddItem()
                };
                return this._AddItemCommand;
            }
        }

        private void AddItem()
        {
            Model newItem = new Model();
            newItem.Code = Items.Count == 0 ? 1 : Items[Items.Count - 1].Code + 1;
            newItem.Name = "Item #" + newItem.Code;

            Items.Add(newItem);
            SelectedItem = newItem;
            NotifyPropertyChanged("Items");
        }

        #region RemoveItemCommand

        public ICommand RemoveItemCommand
        {
            get
            {
                this._RemoveItemCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => CanRemove(),
                    ExecuteDelegate    = p => RemoveItem()
                };
                return this._RemoveItemCommand;
            }
        }

        private bool CanRemove()
        {
            return SelectedItem != null;
        }

        private void RemoveItem()
        {
            Items.Remove(SelectedItem);
            NotifyPropertyChanged("Items");
        }

        #endregion

        #endregion

        public ICommand BadShowYesNoQuestionCommand
        {
            get
            {
                this._ShowYesNoQuestionCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate = p => BadShowYesNoQuestion("Are you sure?")
                };
                return this._ShowYesNoQuestionCommand;
            }
        }

        public ICommand ShowYesNoQuestionCommand
        {
            get
            {
                this._ShowYesNoQuestionCommand = new RelayCommand()
                {
                    CanExecuteDelegate = p => true,
                    ExecuteDelegate = p => GoodShowYesNoQuestion("Are you sure?")
                };
                return this._ShowYesNoQuestionCommand;
            }
        }

        private void BadShowYesNoQuestion(string message)
        {
            MessageBoxResult result;
            result = MessageBox.Show(message, "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    this.Answer = "Your answer is Yes";
                    break;

                default:
                    this.Answer = "Your answer is No";
                    break;
            }
        }

        private void GoodShowYesNoQuestion(string message)
        {
            IMsgBoxService msgbox = GetService<IMsgBoxService>();

            MessageBoxResult result = msgbox.Show(message, "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    this.Answer = "Your answer is Yes";
                    break;

                default:
                    this.Answer = "Your answer is No";
                    break;
            }
        }

        #region Properties

        public string Title
        {
            get
            {
                return _title;
            }

            set
            {
                _title = value;
                NotifyPropertyChanged("Title");
            }
        }

        public Model SelectedItem
        {
            get
            { 
                return _selectedItem; 
            }
            set
            {
                _selectedItem = value;
                NotifyPropertyChanged("SelectedItem");
            }
        }

        public string Answer
        {
            get
            {
                return _answer;
            }

            set
            {
                _answer = value;
                NotifyPropertyChanged("Answer");
            }
        }

        public ObservableCollection<Model> Items { get; set; }

        #endregion

    }
 }
