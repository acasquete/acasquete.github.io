﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BasicMVVM.ViewModels;
using System.Windows;
using System.Windows.Input;
using BasicMvvm.Services;

namespace BasicMVVM.Test
{
    [TestClass]
    public class ViewModelTest
    {
        ViewModel vm = new ViewModel();

        [AssemblyInitialize]
        public static void RegisterServices(TestContext context)
        {
            ServiceLocator.Instance.Register<IMsgBoxService>(new MockMsgBoxService());
        }

        [TestInitialize]
        public void Initialize()
        {
            vm = new ViewModel();
        }

        [TestMethod]
        public void CreateInstance()
        {
            Assert.IsInstanceOfType(vm, typeof(ViewModel));
        }

        [TestMethod]
        public void BadTestExecuteShowQuestionAndAnswerYes()
        {
            ICommand command = vm.BadShowYesNoQuestionCommand;

            command.Execute(null);

            Assert.AreEqual("Your answer is Yes", vm.Answer);
        }

        [TestMethod]
        public void GoodTestExecuteShowQuestionAndAnswerYes()
        {
            ICommand command = vm.ShowYesNoQuestionCommand;
            var msgBox = vm.GetService<IMsgBoxService>() as MockMsgBoxService;
            msgBox.ShowReturnValue = MessageBoxResult.Yes;
            msgBox.ShowCallCount = 0;

            command.Execute(null);

            Assert.AreEqual("Your answer is Yes", vm.Answer);
            Assert.AreEqual(1, msgBox.ShowCallCount);
        }
    }
}
