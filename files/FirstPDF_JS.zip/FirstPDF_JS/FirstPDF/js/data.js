﻿(function () {
    "use strict";

    var dataArray = [];

    var itemList = new WinJS.Binding.List(dataArray);

    WinJS.Namespace.define("Data", {
        pages: itemList,
        addPage: function (url) {
            dataArray.push({page: url});
        }
    });

})();
