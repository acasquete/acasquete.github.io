﻿(function () {
    "use strict";

    var WinPdf = Windows.Data.Pdf;

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            document.getElementById("cmdOpenFile").addEventListener("click", openFile);
        },
    });

    function openFile() {
        var openPicker = new Windows.Storage.Pickers.FileOpenPicker();
        openPicker.viewMode = Windows.Storage.Pickers.PickerViewMode.list;
        openPicker.suggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.documentsLibrary;
        openPicker.fileTypeFilter.replaceAll([".pdf"]);

        openPicker.pickSingleFileAsync().then(function (file) { 

            if (file) {

                WinPdf.PdfDocument.loadFromFileAsync(file).then(function (pdfDocument) {
                    if (pdfDocument !== null) {

                        //renderPage(pdfDocument, 0).then(function (result) {
                        //    pdfImage.src = result.imageSrc;
                        //});

                        renderDocument(pdfDocument);
                        
                    }
                }, function (e) {
                    var es = e;
                });
            }
        });
    }

    function renderDocument(pdfDocument) {
        var pdfFlipView = document.getElementById("pdfFlipView");

        pdfFlipView.winControl.itemDataSource = null;

        var pages = getPageList(pdfDocument);

        pdfFlipView.winControl.itemDataSource = pages.dataSource;
    }

    var pageList = new WinJS.Binding.List();

    function getPageList(pdfDocument) {

        loadPages(pdfDocument).then(function (pageDataArray) {
            for (var i = 0, len = pageDataArray.length; i < len; i++) {
                var index = pageDataArray[i].pageIndex;
                pageList.push({ pageIndex: i, imageSrc: pageDataArray[i].imageSrc });
            }
        });

        return pageList;
    }

    function loadPages(pdfDocument) {
        var promisePages = [];
        for (var index = 0; index < pdfDocument.pageCount; index++) {
            var promise = renderPage(pdfDocument, index).then(function (pageData) {
                return pageData;
            });
            promisePages.push(promise);
        }
        return WinJS.Promise.join(promisePages);
    }

    function renderPage(pdfDocument, pageIndex) {

        var promise = WinJS.Promise.wrap(new Windows.Storage.Streams.InMemoryRandomAccessStream());

        return promise.then(function (pageStream) {
            var pdfPage = pdfDocument.getPage(pageIndex);

            return pdfPage.renderToStreamAsync(pageStream).then(function Flush() {
                return pageStream.flushAsync();
            }).then(function () {

                var renderStream = Windows.Storage.Streams.RandomAccessStreamReference.createFromStream(pageStream);
                return renderStream.openReadAsync().then(function (stream) {

                    pageStream.close();
                    pdfPage.close();

                    var picURL = URL.createObjectURL(stream);

                    return { pageIndex: pageIndex, imageSrc: picURL };

                });
            });
        });
    }
})();
