﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// La informaci�n general de un ensamblado se controla con los siguientes 
// conjuntos de atributos. Cambie los valores de estos atributos para modificar la informaci�n
// asociada con un ensamblado.
[assembly: AssemblyTitle("TicTacToe")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TicTacToe")]
[assembly: AssemblyCopyright("Copyright © 2009 IdleBit")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Si establece ComVisible como false, los tipos de este ensamblado no estar�n visibles 
// para los componentes COM. Si necesita obtener acceso a un tipo de este ensamblado desde 
// COM, establezca el atributo ComVisible como true en este tipo.
[assembly: ComVisible(false)]

// El siguiente GUID sirve como identificador de typelib si este proyecto se expone a COM
[assembly: Guid("dbd5058f-aee0-4c67-a3be-c06db584e841")]

[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
