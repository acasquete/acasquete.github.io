﻿using System.Windows;
using System;

namespace TicTacToe
{
	public partial class App : Application 
	{
		public App() 
		{
			this.Startup += this.OnStartup;
			this.Exit += this.OnExit;
			this.UnhandledException += this.Application_UnhandledException;

			InitializeComponent();
		}

		private void OnStartup(object sender, StartupEventArgs e) 
		{
			// Cargue aquí el control principal
			this.RootVisual = new Page();
		}

		private void OnExit(object sender, EventArgs e) 
		{
		}

		private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e) 
		{
			// Si la aplicación se está ejecutando fuera del depurador, informa de la excepción mediante
			// el mecanismo de excepciones del explorador. En Internet Explorer, este mecanismo muestra un icono de alerta amarillo 
			// en la barra de estado y Firefox muestra un error de script.
			if (!System.Diagnostics.Debugger.IsAttached)
			{
				// NOTA: esto permitirá que la aplicación continúe ejecutándose cuando se produzca una excepción
				// y no se controle. 
				// Para aplicaciones de producción, este control de errores debería reemplazarse por algo que 
				// informe del error al sitio web y detenga la aplicación.
				e.Handled = true;
				Deployment.Current.Dispatcher.BeginInvoke(delegate { ReportErrorToDOM(e); });
			}
		}

		private void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
		{
			try
			{
				string errorMsg = e.ExceptionObject.Message + @"\n" + e.ExceptionObject.StackTrace;
				errorMsg = errorMsg.Replace("\"", "\\\"").Replace("\r\n", @"\n");

				System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight 2 Application " + errorMsg + "\");");
			}
			catch (Exception)
			{
			}
		}
	}
}