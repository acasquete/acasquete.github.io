﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    class Board
    {
        #region Private Members

        private int[] _board;
        private int _winner;
        private int _turn = 1;

        #endregion

        #region Constructor

        public Board()
        {
            _board = new int[9];
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Check if any of the 8 winning positions have the same value
        /// </summary>
        /// <returns>Return -1,1 or 0</returns>
        public int GetWinner()
        {
            int[,] winning = new int[8, 3] { {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, 
                                                       {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, 
                                                       {0, 4, 8}, {2, 4, 6} };

            for (int i = 0; i < 8; i++)
            {
                if (iTablero[winning[i, 0]] == iTablero[winning[i, 1]] &&
                    iTablero[winning[i, 1]] == iTablero[winning[i, 2]] &&
                    iTablero[winning[i, 0]] != 0)
                {
                    _winner = iTablero[winning[i, 0]];
                    return _winner;
                }
            }

            _winner = 0;
            return _winner;
        }

        /// <summary>
        /// Check if all the boxes are occupied
        /// </summary>
        /// <returns>true o false</returns>
        public bool IsTie()
        {
            for (int i = 0; i < 9; i++)
            {
                if (iTablero[i] == 0) return false;
            }
            return true;
        }

        /// <summary>
        /// Devuelve valor indicando si el juego está terminado, es decir hay un ganador o empate
        /// </summary>
        /// <returns></returns>
        public bool GameEnded()
        {
            return (GetWinner() != 0 || IsTie());
        }

        /// <summary>
        /// Devuelve un array con todos los movimientos permitidos
        /// </summary>
        /// <param name="randomStart">Indica si se comienza a comprobar por una casilla aleatoria</param>
        /// <returns></returns>
        public int[] GetAllowedMovements(bool randomStart)
        {
            List<int> movements = new List<int>();

            int j = 0;

            if (randomStart)
            {
                j = new Random().Next(0,8);
            }

            for (int i = 0; i < 9; i++, j++)
            {
                if (j > 8) j = 0;
                if (iTablero[j] == 0) movements.Add(j);
            }
            return (movements.ToArray());
        }

        public void ApplyMovement(int posicion)
        {
            iTablero[posicion] = _turn;
            _turn = -_turn;
        }

        public object Clone()
        {
            Board board = (Board)base.MemberwiseClone();
            board._board = (int[])iTablero.Clone();
            return board;
        }
        #endregion

        #region Read-Only Properties

        public int Winner
        {
            get { return _winner; }
        }

        public int[] iTablero
        {
            get { return _board; }
        }

        public int Turn
        {
            get { return _turn; }
        }

        #endregion
    }

    class Movement
    {
        #region Public Members

        public int Value;
        public int Position;
        public Movement() { }

        #endregion
    }
}
