﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TicTacToe
{
	public partial class Page : UserControl
	{
        int[] tipojugadores = new int[2] { -1, -1 }; // Ordenador -1  Humano 1
        int empiezajuego = 0; 
        int turnojugador = 0;
        IAGame game;

		public Page()
		{
			InitializeComponent();
		}

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            InicializaTablero();
        }

        private void InicializaTablero()
        {
            this.Casillas.Children.Clear();

            for (int i = 0, j = 0, k = 0; i < 9; i++, j++)
            {
                Square c = new Square();
                c.SetValue(Canvas.LeftProperty, (double)j * 93 + (10 * j) + 6);
                c.SetValue(Canvas.TopProperty, (double)k * 93 + (10 * k) + 6);
                c.Position = i;
                c.Name = "Casilla" + i;
                if ((i + 1) % 3 == 0) { k++; j = -1; }
                c.MouseLeftButtonUp += new MouseButtonEventHandler(c_MouseLeftButtonUp);
                c.ColocaCruz.Completed+=new EventHandler(ColocaFicha_Completed);
                c.ColocaCirculo.Completed += new EventHandler(ColocaFicha_Completed);
                this.Casillas.Children.Add(c);
            }

            game = new IAGame();
            turnojugador = empiezajuego;
            if (tipojugadores[empiezajuego] == -1) JuegaOrdenador();
            empiezajuego = empiezajuego == 0 ? 1 : 0;

        }

        void ColocaFicha_Completed(object sender, EventArgs e)
        {
            CompruebaGanador();
        }

        private void JuegaOrdenador()
        {
            int posicion = game.PlayComputer();
            Square cpu = (Square)this.Casillas.FindName("Casilla" + posicion);

            AnimaFicha(cpu);

        }

        private void AnimaFicha(Square cpu)
        {
            if (game.Board.Turn == 1) // Siguiente turno es cruz entonces colocamos circulo
            {
                cpu.ColocaCirculo.Begin();
            }
            else
            {
                cpu.ColocaCruz.Begin();
            }
        }

        void c_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Square c = (Square)sender;
            game.PlayHuman(c.Position);
            AnimaFicha(c);
        }

        private void CompruebaGanador()
        {
            turnojugador = turnojugador == 0 ? 1 : 0;

            int Ganador = game.Board.GetWinner();

            if (Ganador != 0 || game.Board.IsTie())
            {
                if (Ganador == 0)
                {
                    InicializaTablero();
                }
            }
            else
            {
                if (tipojugadores[turnojugador] == -1) JuegaOrdenador();
            }
        }
    

	}
}