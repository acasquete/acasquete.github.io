﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    class IAGame
    {
        #region Private Members

        private Board _board;

        #endregion

        #region Constructor

        public IAGame()
        {
            _board = new Board();
        }

        #endregion

        #region Public Methods

        public void PlayHuman(int position)
        {
            _board.ApplyMovement(position);
        }

        public int PlayComputer()
        {
            Movement best = MiniMaxAlphaBetaDepth(_board, Board.Turn, 0, -1, 1);
            
            _board.ApplyMovement(best.Position);
            return best.Position;
        }

        #endregion

        #region Private Methods (MiniMax Algorithm)

        private Movement MiniMax(Board board, int player)
        {
            if (board.GameEnded())
            {
                Movement mov = new Movement();
                mov.Value = board.Winner;
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(true);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.ApplyMovement(successor);
                    Movement tmp = MiniMax(successorBoard, -player);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }
                }
                return best;
            }
        }

        private Movement MiniMaxAlphaBeta(Board board, int player, int alpha, int beta)
        {
            if (board.GameEnded())
            {
                Movement mov = new Movement();
                mov.Value = board.Winner;
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(true);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.ApplyMovement(successor);
                    Movement tmp = MiniMaxAlphaBeta(successorBoard, -player, alpha, beta);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }

                    if (player == -1 && best.Value < beta)
                        beta = best.Value;
                    if (player == 1 && best.Value > alpha)
                        alpha = best.Value;

                    if (alpha > beta)
                    {
                        return best;
                    }
                }
                return best;
            }
        }

        private Movement MiniMaxAlphaBetaDepth(Board board, int player, int depth, int alpha, int beta)
        {
            if (board.GameEnded() || depth==6)
            {
                Movement mov = new Movement();
                mov.Value = board.Winner;
                return mov;
            }
            else
            {
                int[] successors = board.GetAllowedMovements(true);
                Movement best = null;

                foreach (int successor in successors)
                {
                    Board successorBoard = (Board)board.Clone();
                    successorBoard.ApplyMovement(successor);
                    Movement tmp = MiniMaxAlphaBetaDepth(successorBoard, -player, depth+1, alpha, beta);

                    if (best == null || (player == -1 && tmp.Value < best.Value) || (player == 1 && tmp.Value > best.Value))
                    {
                        tmp.Position = successor;
                        best = tmp;
                    }

                    if (player == -1 && best.Value < beta)
                        beta = best.Value;
                    if (player == 1 && best.Value > alpha)
                        alpha = best.Value;

                    if (alpha > beta)
                    {
                        return best;
                    }
                }
                return best;
            }
        }

        #endregion

        #region Public Read-Only Properties

        public Board Board
        {
            get { return _board; }
        }

        #endregion

    }
}
