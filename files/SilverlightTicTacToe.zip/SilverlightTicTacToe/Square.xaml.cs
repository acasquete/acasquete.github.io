﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TicTacToe
{
	public partial class Square : UserControl
    {
        #region Private Members

        int _position;

        #endregion 

        #region Constructor

        public Square()
        {
            InitializeComponent();
        }

        #endregion

        #region Public Properties

        public int Position 
        { 
            get 
            {
                return _position; 
            }
            set 
            {
                _position = value; 
            }
        }

        #endregion
    }
}